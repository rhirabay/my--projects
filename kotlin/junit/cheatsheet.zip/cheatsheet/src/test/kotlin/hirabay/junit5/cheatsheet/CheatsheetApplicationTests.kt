package hirabay.junit5.cheatsheet

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class CheatsheetApplicationTests {

	@Test
	fun contextLoads() {
	}

}
