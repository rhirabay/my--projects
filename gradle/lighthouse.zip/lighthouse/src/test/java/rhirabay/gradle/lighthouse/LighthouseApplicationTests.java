package rhirabay.gradle.lighthouse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LighthouseApplicationTests {

	@Test
	void contextLoads() {
	}

}
